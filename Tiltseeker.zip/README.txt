Tiltseeker Desktop App
~~~~~~~~~~~~~~~~~~~~~~

A simple script to automatically open up tiltseeker.com when a League game starts.

Use:
-Run Tiltseeker.exe
-Set Username and Region
-Play League